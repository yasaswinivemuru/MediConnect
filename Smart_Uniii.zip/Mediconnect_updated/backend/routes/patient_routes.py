from flask import Blueprint, jsonify, request, current_app
from werkzeug.utils import secure_filename
import os
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, PatientProfile, MedicalHistory, DoctorProfile, Appointment
from datetime import datetime
from utils.qr_utils import generate_qr_code
import json

patient_bp = Blueprint('patient', __name__)

@patient_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user or user.role != 'PATIENT':
        return jsonify({"message": "Unauthorized"}), 403

    profile = user.patient_profile
    
    return jsonify({
        "name": user.name,
        "email": user.email,
        "age": profile.age,
        "gender": profile.gender,
        "bloodGroup": profile.blood_group,
        "phone": profile.phone,
        "address": profile.address,
        "height": profile.height,
        "emergencyName": profile.emergency_name,
        "emergencyRelation": profile.emergency_relation,
        "emergencyPhone": profile.emergency_phone,
        "allergies": profile.allergies,
        "conditions": profile.conditions,
        "medications": profile.medications,
        "insuranceProvider": profile.insurance_provider,
        "policyNumber": profile.policy_number,
        "profilePicture": profile.profile_picture
    })

@patient_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    profile = user.patient_profile
    
    data = request.json
    profile.age = data.get('age', profile.age)
    profile.gender = data.get('gender', profile.gender)
    profile.blood_group = data.get('bloodGroup', profile.blood_group)
    profile.phone = data.get('phone', profile.phone)
    profile.address = data.get('address', profile.address)
    profile.height = data.get('height', profile.height)
    profile.emergency_name = data.get('emergencyName', profile.emergency_name)
    profile.emergency_relation = data.get('emergencyRelation', profile.emergency_relation)
    profile.emergency_phone = data.get('emergencyPhone', profile.emergency_phone)
    profile.allergies = data.get('allergies', profile.allergies)
    profile.conditions = data.get('conditions', profile.conditions)
    profile.medications = data.get('medications', profile.medications)
    profile.insurance_provider = data.get('insuranceProvider', profile.insurance_provider)
    profile.policy_number = data.get('policyNumber', profile.policy_number)
    
    db.session.commit()
    return jsonify({"success": True, "message": "Profile updated"})

@patient_bp.route('/history', methods=['GET'])
@jwt_required()
def get_history():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    profile = user.patient_profile
    
    history = []
    for h in profile.medical_history:
        history.append({
            "date": h.date.strftime('%Y-%m-%d'),
            "condition": h.condition,
            "treatment": h.treatment,
            "notes": h.notes,
            "vitals": {
                "bp": h.bp,
                "sugar": h.sugar,
                "weight": h.weight
            }
        })
        
    return jsonify(history)

@patient_bp.route('/history', methods=['POST'])
@jwt_required()
def add_history():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    profile = user.patient_profile
    
    data = request.json
    
    # Parse date or use today
    record_date = datetime.utcnow().date()
    
    new_history = MedicalHistory(
        patient_id=profile.id,
        date=record_date,
        condition=data.get('risk', 'Unknown'), # Mapping risk to condition for now
        treatment=data.get('treatment', ''),
        notes=data.get('notes', ''),
        bp=data.get('bp'),
        sugar=str(data.get('sugar')),
        weight=float(data.get('weight', 0)) if data.get('weight') else None
    )
    
    db.session.add(new_history)
    db.session.commit()
    
    return jsonify({"success": True, "message": "Health record added"})

@patient_bp.route('/doctors', methods=['GET'])
@jwt_required()
def get_doctors():
    doctors = DoctorProfile.query.all()
    doctor_list = []
    for d in doctors:
        doctor_list.append({
            "id": d.id,
            "name": d.user.name,
            "specialization": d.specialization,
            "experience": d.experience
        })
    return jsonify(doctor_list)

@patient_bp.route('/appointments', methods=['GET'])
@jwt_required()
def get_appointments():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    profile = user.patient_profile
    
    appointments = []
    for appt in profile.appointments:
        appointments.append({
            "id": appt.id,
            "doctorName": appt.doctor.user.name,
            "specialization": appt.doctor.specialization,
            "dateTime": appt.date_time.isoformat(),
            "status": appt.status,
            "reason": appt.reason
        })
    
    # Sort by date descending
    appointments.sort(key=lambda x: x['dateTime'], reverse=True)
    return jsonify(appointments)

@patient_bp.route('/appointments', methods=['POST'])
@jwt_required()
def book_appointment():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    profile = user.patient_profile
    
    data = request.json
    doctor_id = data.get('doctorId')
    date_str = data.get('date') # YYYY-MM-DD
    time_str = data.get('time') # HH:MM
    reason = data.get('reason')
    
    if not all([doctor_id, date_str, time_str]):
        return jsonify({"success": False, "message": "Missing required fields"}), 400
        
    try:
        dt_str = f"{date_str} {time_str}"
        appt_datetime = datetime.strptime(dt_str, '%Y-%m-%d %H:%M')
        
        new_appt = Appointment(
            patient_id=profile.id,
            doctor_id=doctor_id,
            date_time=appt_datetime,
            reason=reason,
            status='Scheduled'
        )
        
        db.session.add(new_appt)
        db.session.commit()
        
        return jsonify({"success": True, "message": "Appointment booked successfully"})
    except ValueError:
        return jsonify({"success": False, "message": "Invalid date/time format"}), 400
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@patient_bp.route('/qr', methods=['GET'])
@jwt_required()
def get_qr():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    profile = user.patient_profile
    
    if not profile:
        return jsonify({"message": "Profile not found"}), 404
        
    # Data to encode in QR
    qr_data = json.dumps({
        "patientId": profile.id,
        "name": user.name,
        "type": "MEDICONNECT_PATIENT"
    })
    
    qr_image = generate_qr_code(qr_data)
    
    return jsonify({
        "qrImage": f"data:image/png;base64,{qr_image}",
        "patientId": profile.id
    })

UPLOAD_FOLDER = 'static/uploads/reports'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@patient_bp.route('/upload_report', methods=['POST'])
@jwt_required()
def upload_report():
    if 'file' not in request.files:
        return jsonify({"success": False, "message": "No file part"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"success": False, "message": "No selected file"}), 400
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # Ensure directory exists
        # We use static folder so it can be served
        upload_path = os.path.join(current_app.root_path, '..', UPLOAD_FOLDER)
        os.makedirs(upload_path, exist_ok=True)
        
        save_path = os.path.join(upload_path, filename)
        file.save(save_path)
        
        # Return the relative path or URL
        return jsonify({"success": True, "url": f"/{UPLOAD_FOLDER}/{filename}"})
    
    return jsonify({"success": False, "message": "File type not allowed"}), 400

@patient_bp.route('/upload_profile_pic', methods=['POST'])
@jwt_required()
def upload_profile_pic():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    profile = user.patient_profile
    
    if 'file' not in request.files:
        return jsonify({"success": False, "message": "No file part"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"success": False, "message": "No selected file"}), 400
        
    if file and allowed_file(file.filename):
        filename = secure_filename(f"profile_{user.id}_{file.filename}")
        upload_path = os.path.join(current_app.root_path, '..', 'static/uploads/profiles')
        os.makedirs(upload_path, exist_ok=True)
        
        save_path = os.path.join(upload_path, filename)
        file.save(save_path)
        
        profile.profile_picture = f"/static/uploads/profiles/{filename}"
        db.session.commit()
        
        return jsonify({"success": True, "url": profile.profile_picture})
    
    return jsonify({"success": False, "message": "File type not allowed"}), 400
