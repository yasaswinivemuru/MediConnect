from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, DoctorProfile, PatientProfile, Appointment

admin_bp = Blueprint('admin', __name__)

def is_admin():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    return user and user.role == 'ADMIN'

@admin_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_stats():
    if not is_admin():
        return jsonify({"message": "Unauthorized"}), 403
        
    total_patients = PatientProfile.query.count()
    total_doctors = DoctorProfile.query.count()
    total_appointments = Appointment.query.count()
    
    return jsonify({
        "totalPatients": total_patients,
        "totalDoctors": total_doctors,
        "totalAppointments": total_appointments
    })

@admin_bp.route('/users', methods=['GET'])
@jwt_required()
def get_users():
    if not is_admin():
        return jsonify({"message": "Unauthorized"}), 403
        
    users = User.query.all()
    user_list = []
    for u in users:
        user_list.append({
            "id": u.id,
            "name": u.name,
            "email": u.email,
            "role": u.role,
            "created_at": u.created_at.isoformat()
        })
    return jsonify(user_list)

@admin_bp.route('/users/<int:id>', methods=['DELETE'])
@jwt_required()
def delete_user(id):
    if not is_admin():
        return jsonify({"message": "Unauthorized"}), 403
        
    user = User.query.get(id)
    if not user:
        return jsonify({"message": "User not found"}), 404
        
    # Delete associated profiles
    if user.patient_profile:
        db.session.delete(user.patient_profile)
    if user.doctor_profile:
        db.session.delete(user.doctor_profile)
        
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({"success": True, "message": "User deleted"})
