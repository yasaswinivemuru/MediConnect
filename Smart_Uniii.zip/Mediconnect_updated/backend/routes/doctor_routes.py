from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, DoctorProfile, PatientProfile, Appointment, MedicalHistory
from datetime import datetime, timedelta
from flask import request

doctor_bp = Blueprint('doctor', __name__)

@doctor_bp.route('/patients', methods=['GET'])
@jwt_required()
def get_patients():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    doctor = user.doctor_profile
    
    # Get patients who have appointments with this doctor
    # We use a set to avoid duplicates
    appointments = Appointment.query.filter_by(doctor_id=doctor.id).all()
    patient_ids = set([appt.patient_id for appt in appointments])
    
    patients = PatientProfile.query.filter(PatientProfile.id.in_(patient_ids)).all()
    
    patient_list = []
    for p in patients:
        patient_list.append({
            "id": p.id,
            "name": p.user.name,
            "age": p.age,
            "bloodGroup": p.blood_group,
            "phone": p.phone
        })
        
    return jsonify(patient_list)

@doctor_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_stats():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    doctor = user.doctor_profile
    
    # Real stats
    total_patients = Appointment.query.with_entities(Appointment.patient_id).filter_by(doctor_id=doctor.id).distinct().count()
    
    today = datetime.utcnow().date()
    # Filter appointments for today. Note: date_time is DateTime, so we need to filter by range or cast
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())
    
    today_appointments = Appointment.query.filter(
        Appointment.doctor_id == doctor.id,
        Appointment.date_time >= today_start,
        Appointment.date_time <= today_end
    ).count()
    
    pending_consultations = Appointment.query.filter_by(doctor_id=doctor.id, status='Scheduled').count()
    
    return jsonify({
        "totalPatients": total_patients,
        "todayAppointments": today_appointments, 
        "pendingConsultations": pending_consultations
    })

@doctor_bp.route('/appointments', methods=['GET'])
@jwt_required()
def get_appointments():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    doctor = user.doctor_profile
    
    appointments = Appointment.query.filter_by(doctor_id=doctor.id).order_by(Appointment.date_time.desc()).all()
    
    appt_list = []
    for appt in appointments:
        appt_list.append({
            "id": appt.id,
            "patientName": appt.patient.user.name,
            "dateTime": appt.date_time.isoformat(),
            "status": appt.status,
            "reason": appt.reason,
            "patientId": appt.patient_id
        })
        
    return jsonify(appt_list)

@doctor_bp.route('/appointments/<int:id>/status', methods=['PUT'])
@jwt_required()
def update_appointment_status(id):
    data = request.json
    status = data.get('status')
    
    appt = Appointment.query.get(id)
    if not appt:
        return jsonify({"success": False, "message": "Appointment not found"}), 404
        
    appt.status = status
    db.session.commit()
    
    return jsonify({"success": True, "message": "Status updated"})

@doctor_bp.route('/scan', methods=['POST'])
@jwt_required()
def scan_patient_qr():
    data = request.json
    patient_id = data.get('patientId')
    
    if not patient_id:
        return jsonify({"success": False, "message": "Patient ID required"}), 400
        
    patient = PatientProfile.query.get(patient_id)
    if not patient:
        return jsonify({"success": False, "message": "Patient not found"}), 404
        
    # Fetch last 1 year history
    one_year_ago = datetime.utcnow() - timedelta(days=365)
    history = MedicalHistory.query.filter(
        MedicalHistory.patient_id == patient_id,
        MedicalHistory.date >= one_year_ago
    ).order_by(MedicalHistory.date.desc()).all()
    
    history_list = []
    for h in history:
        history_list.append({
            "date": h.date.strftime('%Y-%m-%d'),
            "condition": h.condition,
            "treatment": h.treatment,
            "notes": h.notes,
            "reportUrl": h.report_url
        })
        
    return jsonify({
        "success": True,
        "patient": {
            "name": patient.user.name,
            "age": patient.age,
            "gender": patient.gender,
            "bloodGroup": patient.blood_group,
            "id": patient.id
        },
        "history": history_list
    })
