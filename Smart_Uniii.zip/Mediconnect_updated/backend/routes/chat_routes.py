from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, Message
from datetime import datetime

chat_bp = Blueprint('chat', __name__)

@chat_bp.route('/messages/<int:user_id>', methods=['GET'])
@jwt_required()
def get_messages(user_id):
    current_user_id = get_jwt_identity()
    
    # Get messages between current user and user_id
    messages = Message.query.filter(
        ((Message.sender_id == current_user_id) & (Message.receiver_id == user_id)) |
        ((Message.sender_id == user_id) & (Message.receiver_id == current_user_id))
    ).order_by(Message.timestamp).all()
    
    msg_list = []
    for m in messages:
        msg_list.append({
            "id": m.id,
            "senderId": m.sender_id,
            "content": m.content,
            "timestamp": m.timestamp.isoformat()
        })
        
    return jsonify(msg_list)

@chat_bp.route('/send', methods=['POST'])
@jwt_required()
def send_message():
    current_user_id = get_jwt_identity()
    data = request.json
    receiver_id = data.get('receiverId')
    content = data.get('content')
    
    if not receiver_id or not content:
        return jsonify({"success": False, "message": "Missing fields"}), 400
        
    msg = Message(
        sender_id=current_user_id,
        receiver_id=receiver_id,
        content=content
    )
    
    db.session.add(msg)
    db.session.commit()
    
    return jsonify({"success": True, "message": "Message sent"})
