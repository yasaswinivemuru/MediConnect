from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, Notification
from datetime import datetime

notification_bp = Blueprint('notification', __name__)

@notification_bp.route('/', methods=['GET'])
@jwt_required()
def get_notifications():
    current_user_id = get_jwt_identity()
    
    # Get unread notifications first, then read, limit to 20
    notifications = Notification.query.filter_by(user_id=current_user_id)\
        .order_by(Notification.is_read.asc(), Notification.created_at.desc())\
        .limit(20).all()
        
    notif_list = []
    for n in notifications:
        notif_list.append({
            "id": n.id,
            "message": n.message,
            "isRead": n.is_read,
            "createdAt": n.created_at.isoformat()
        })
        
    return jsonify(notif_list)

@notification_bp.route('/<int:id>/read', methods=['PUT'])
@jwt_required()
def mark_as_read(id):
    current_user_id = get_jwt_identity()
    
    notification = Notification.query.get(id)
    if not notification:
        return jsonify({"message": "Notification not found"}), 404
        
    if notification.user_id != current_user_id:
        return jsonify({"message": "Unauthorized"}), 403
        
    notification.is_read = True
    db.session.commit()
    
    return jsonify({"success": True})

@notification_bp.route('/create', methods=['POST'])
@jwt_required()
def create_notification_internal():
    # This route might be restricted to internal use or Admin
    # For now allowing logic to demonstrate creation
    data = request.json
    user_id = data.get('userId')
    message = data.get('message')
    
    if not user_id or not message:
        return jsonify({"message": "Missing fields"}), 400
        
    notif = Notification(user_id=user_id, message=message)
    db.session.add(notif)
    db.session.commit()
    
    return jsonify({"success": True, "id": notif.id})
