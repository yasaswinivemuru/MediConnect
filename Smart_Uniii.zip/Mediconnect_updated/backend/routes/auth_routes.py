from flask import Blueprint, request, jsonify
from models import db, User, PatientProfile, DoctorProfile
from flask_bcrypt import Bcrypt
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity

auth_bp = Blueprint('auth', __name__)
bcrypt = Bcrypt()

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    role = data.get('role', 'PATIENT').upper()
    name = data.get('name')

    if User.query.filter_by(email=email).first():
        return jsonify({"success": False, "message": "Email already exists"}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    new_user = User(email=email, password=hashed_password, role=role, name=name)
    
    db.session.add(new_user)
    db.session.commit()

    # Create profile based on role
    if role == 'PATIENT':
        profile = PatientProfile(
            user_id=new_user.id,
            phone=data.get('phone'),
            age=data.get('age'),
            gender=data.get('gender')
        )
        db.session.add(profile)
    elif role == 'DOCTOR':
        profile = DoctorProfile(
            user_id=new_user.id,
            specialization=data.get('specialization')
        )
        db.session.add(profile)
    
    db.session.commit()

    return jsonify({"success": True, "message": "User registered successfully"})

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    user = User.query.filter_by(email=email).first()

    if user and bcrypt.check_password_hash(user.password, password):
        access_token = create_access_token(identity=user.id)
        return jsonify({
            "success": True,
            "message": "Login successful",
            "token": access_token,
            "user": {
                "id": user.id,
                "email": user.email,
                "name": user.name,
                "role": user.role
            }
        })
    
    return jsonify({"success": False, "message": "Invalid email or password"}), 401

@auth_bp.route('/change_password', methods=['POST'])
@jwt_required()
def change_password():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    data = request.json
    old_password = data.get('oldPassword')
    new_password = data.get('newPassword')
    
    if not user or not bcrypt.check_password_hash(user.password, old_password):
        return jsonify({"success": False, "message": "Incorrect old password"}), 400
        
    user.password = bcrypt.generate_password_hash(new_password).decode('utf-8')
    db.session.commit()
    
    return jsonify({"success": True, "message": "Password updated successfully"})
