from app import app, db
from models import User, PatientProfile, DoctorProfile, MedicalHistory, Appointment
from flask_bcrypt import Bcrypt
from datetime import date, datetime, timedelta

bcrypt = Bcrypt()

def seed_database():
    with app.app_context():
        print("Dropping old data...")
        db.drop_all()
        db.create_all()

        print("Creating users...")
        # Create Patient
        pw_hash = bcrypt.generate_password_hash('password123').decode('utf-8')
        patient_user = User(email='patient@example.com', password=pw_hash, role='PATIENT', name='Srinivas Patient')
        db.session.add(patient_user)
        db.session.commit()

        patient_profile = PatientProfile(
            user_id=patient_user.id,
            age=25,
            gender='Male',
            blood_group='O+',
            phone='9876543210',
            address='123 Main St, Tech City'
        )
        db.session.add(patient_profile)

        # Create Doctor
        doctor_user = User(email='doctor@example.com', password=pw_hash, role='DOCTOR', name='Dr. Strange')
        db.session.add(doctor_user)
        db.session.commit()

        doctor_profile = DoctorProfile(
            user_id=doctor_user.id,
            specialization='Cardiology',
            experience=10,
            phone='1122334455'
        )
        db.session.add(doctor_profile)
        db.session.commit()

        # Create Admin
        admin_user = User(email='admin@example.com', password=pw_hash, role='ADMIN', name='Super Admin')
        db.session.add(admin_user)
        db.session.commit()

        # Add Medical History
        history1 = MedicalHistory(
            patient_id=patient_profile.id,
            date=date(2024, 1, 15),
            condition='Viral Fever',
            treatment='Paracetamol 500mg',
            notes='Rest advised for 3 days',
            bp='120/80',
            sugar='90',
            weight=70.5
        )
        db.session.add(history1)
        db.session.commit()

        # Add Appointment
        appt = Appointment(
            patient_id=patient_profile.id,
            doctor_id=doctor_profile.id,
            date_time=datetime.utcnow() + timedelta(days=1),
            reason='Regular Checkup',
            status='Scheduled'
        )
        db.session.add(appt)
        db.session.commit()

        print("Database seeded successfully!")

if __name__ == '__main__':
    seed_database()
