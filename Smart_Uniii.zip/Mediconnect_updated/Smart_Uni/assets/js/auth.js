// Check authentication state on every page load
function checkAuth() {
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');
  const currentPath = window.location.pathname;

  // If on a protected page without auth, redirect to login
  if (!token && !currentPath.includes('/home_pages/')) {
    window.location.href = '../home_pages/login.html';
    return;
  }

  // If authenticated but on home pages, redirect to appropriate dashboard
  if (token && currentPath.includes('/home_pages/') && currentPath !== '/home_pages/index.html') {
    switch (role) {
      case 'ADMIN':
        window.location.href = '../admin_modules/admin-dashboard.html';
        break;
      case 'DOCTOR':
        window.location.href = '../doctors_modules/doctor-dashboard.html';
        break;
      case 'PATIENT':
        window.location.href = '../patient_modules/patient-dashboard.html';
        break;
      case 'STAFF':
        window.location.href = '../staff_modules/staff-dashboard.html';
        break;
    }
    return;
  }

  // If on wrong module for role, redirect to correct one
  if (token && role) {
    const currentModule = currentPath.split('/')[1];
    const correctModule = role.toLowerCase() + '_modules';
    if (currentModule !== correctModule && !currentPath.includes('/home_pages/')) {
      switch (role) {
        case 'ADMIN':
          window.location.href = '../admin_modules/admin-dashboard.html';
          break;
        case 'DOCTOR':
          window.location.href = '../doctors_modules/doctor-dashboard.html';
          break;
        case 'PATIENT':
          window.location.href = '../patient_modules/patient-dashboard.html';
          break;
        case 'STAFF':
          window.location.href = '../staff_modules/staff-dashboard.html';
          break;
      }
    }
  }
}

// Run auth check when page loads
document.addEventListener('DOMContentLoaded', checkAuth);