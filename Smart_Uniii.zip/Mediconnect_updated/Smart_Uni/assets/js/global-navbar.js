// Global navbar JS: fills username, highlights active link, exposes logout helper
window.addEventListener('DOMContentLoaded', () => {
  try {
    const userName = localStorage.getItem('userName');
    const role = localStorage.getItem('role');

    // Populate all common selectors for name
    document.querySelectorAll('.user-name, #userName, #patientName, #welcomeName, .doctor-info .name, .patient-info .name, .name.mt-1').forEach(el => {
      if (userName) el.textContent = userName;
    });

    // Highlight active nav-link by comparing last segment (filename)
    const current = window.location.pathname.split('/').pop();
    if (current) {
      document.querySelectorAll('.nav-link').forEach(link => {
        const href = link.getAttribute('href');
        if (!href) return;
        const linkFile = href.split('/').pop();
        if (linkFile === current) {
          link.classList.add('active');
        }
      });
    }

    // Attach a global logout helper (pages can call logoutUser() or confirmLogout())
    window.logoutUser = function(redirectTo = '../home_pages/login.html') {
      localStorage.clear();
      // small delay to ensure storage cleared
      setTimeout(() => { window.location.href = redirectTo; }, 80);
    };
  } catch (e) {
    console.error('global-navbar error', e);
  }
});
