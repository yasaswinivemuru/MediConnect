/**
 * Backend API Configuration
 * Contains all API endpoints and utility functions
 */
(function () {
    // Backend API Base URL
    const API_BASE_URL = 'http://127.0.0.1:5000/api';

    // Store JWT token in localStorage
    function setAuthToken(token) {
        localStorage.setItem('token', token);
    }

    // Get JWT token from localStorage
    function getAuthToken() {
        return localStorage.getItem('token');
    }

    // Remove JWT token
    function removeAuthToken() {
        localStorage.removeItem('token');
    }

    // Common fetch options with JWT token
    function getAuthHeaders() {
        const token = getAuthToken();
        return {
            'Content-Type': 'application/json',
            'Authorization': token ? `Bearer ${token}` : ''
        };
    }

    // Generic API Request Handler
    async function apiRequest(endpoint, method = 'GET', body = null, isFileUpload = false) {
        const url = `${API_BASE_URL}${endpoint}`;
        const options = {
            method,
            headers: isFileUpload ?
                { 'Authorization': `Bearer ${getAuthToken()}` } :
                getAuthHeaders(),
        };

        if (body && !isFileUpload) {
            options.body = JSON.stringify(body);
        } else if (body && isFileUpload) {
            options.body = body;
        }

        try {
            const response = await fetch(url, options);
            const data = await response.json();

            if (!response.ok) {
                if (response.status === 401) {
                    API.logout();
                    window.location.href = '../home_pages/login.html';
                }
                throw new Error(data.message || 'API Request Failed');
            }

            return data;
        } catch (error) {
            console.error(`API Error (${endpoint}):`, error);
            throw error;
        }
    }

    const API = {
        // Auth
        register: (userData) => apiRequest('/auth/register', 'POST', userData),
        login: async (email, password) => {
            const response = await apiRequest('/auth/login', 'POST', { email, password });
            if (response.success) {
                setAuthToken(response.token);
                localStorage.setItem('role', response.user.role);
                localStorage.setItem('userName', response.user.name);
                localStorage.setItem('email', response.user.email);
                localStorage.setItem('userId', response.user.id);
            }
            return response;
        },
        logout: () => {
            removeAuthToken();
            localStorage.clear();
        },
        changePassword: (oldPassword, newPassword) => apiRequest('/auth/change_password', 'POST', { oldPassword, newPassword }),

        // Notifications
        getNotifications: () => apiRequest('/notification/', 'GET'),
        markNotificationRead: (id) => apiRequest(`/notification/${id}/read`, 'PUT'),

        // Chat
        getMessages: (userId) => apiRequest(`/chat/messages/${userId}`, 'GET'),
        sendMessage: (receiverId, content) => apiRequest('/chat/send', 'POST', { receiverId, content }),

        // Patient
        getPatientProfile: () => apiRequest('/patient/profile', 'GET'),
        updatePatientProfile: (patientData) => apiRequest('/patient/profile', 'PUT', patientData),
        getMedicalHistory: () => apiRequest('/patient/history', 'GET'),
        addMedicalHistory: (historyData) => apiRequest('/patient/history', 'POST', historyData),
        getPatientAppointments: () => apiRequest('/patient/appointments', 'GET'),
        bookAppointment: (appointmentData) => apiRequest('/patient/appointments', 'POST', appointmentData),
        uploadMedicalReport: (formData) => apiRequest('/patient/upload_report', 'POST', formData, true),
        uploadProfilePic: (formData) => apiRequest('/patient/upload_profile_pic', 'POST', formData, true),
        getDoctors: () => apiRequest('/patient/doctors', 'GET'),
        getPatientQR: () => apiRequest('/patient/qr', 'GET'),

        // Doctor
        getDoctorPatients: () => apiRequest('/doctor/patients', 'GET'),
        getDoctorStats: () => apiRequest('/doctor/stats', 'GET'),
        getDoctorAppointments: () => apiRequest('/doctor/appointments', 'GET'),
        updateAppointmentStatus: (id, status) => apiRequest(`/doctor/appointments/${id}/status`, 'PUT', { status }),
        scanPatientQR: (patientId) => apiRequest('/doctor/scan', 'POST', { patientId })
    };

    window.MediConnectAPI = API;
})();
