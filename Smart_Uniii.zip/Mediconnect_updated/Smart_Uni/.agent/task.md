# Task: Update All Files

## Status
- [ ] Analyze current state of files to identify necessary updates <!-- id: 0 -->
- [ ] Clarify specific update requirements with user if not obvious <!-- id: 1 -->
- [ ] Apply updates to `doctors_modules` <!-- id: 2 -->
- [ ] Apply updates to `patient_modules` <!-- id: 3 -->
- [ ] Verify consistency across all modules <!-- id: 4 -->
