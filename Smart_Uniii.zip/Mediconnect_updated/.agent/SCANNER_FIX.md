# QR Scanner - Recommended Implementation

## Problem
Currently, `scan-qr.html` only uses data from the QR code (localStorage). It doesn't fetch real-time data from the backend.

## Solution
Modify `scan-qr.html` to:
1. Scan QR code to get `patientId`
2. Call backend API to fetch full patient data
3. Display comprehensive medical history

## Updated Code for `scan-qr.html`

### Change the `onScanSuccess` function:

```javascript
async function onScanSuccess(decodedText, decodedResult) {
    console.log(`Code matched = ${decodedText}`, decodedResult);

    try {
        // Parse QR code data
        const qrData = JSON.parse(decodedText);
        
        // Extract patient ID
        let patientId = null;
        
        // Check if it's the new format (with type)
        if (qrData.type === 'MEDICONNECT_PATIENT' && qrData.patientId) {
            patientId = qrData.patientId;
        }
        // Or old format (with name, age, etc)
        else if (qrData.name) {
            // If QR has full data but no ID, use the data directly
            localStorage.setItem('scannedPatientData', decodedText);
            document.getElementById('scanStatus').textContent = "✅ Scan Successful! Redirecting...";
            setTimeout(() => {
                window.location.href = 'scanned-patient-history.html';
            }, 1000);
            return;
        }
        
        if (!patientId) {
            document.getElementById('scanStatus').textContent = "❌ Invalid QR Code format.";
            return;
        }

        // Stop scanning
        if (html5QrcodeScanner) {
            stopScanning();
        }

        // Fetch from backend
        document.getElementById('scanStatus').textContent = "📡 Fetching patient data from server...";
        
        const result = await MediConnectAPI.scanPatientQR(patientId);
        
        if (result.success) {
            // Transform backend data to match display format
            const patientData = {
                name: result.patient.name,
                age: result.patient.age,
                bloodGroup: result.patient.bloodGroup,
                lastVisit: result.history.length > 0 ? result.history[0].date : 'N/A',
                vitals: {
                    bp: result.history.length > 0 ? result.history[0].bp : 'N/A',
                    sugar: result.history.length > 0 ? result.history[0].sugar : 'N/A',
                    bmi: 'N/A', // Calculate if weight/height available
                    risk: result.history.length > 0 ? result.history[0].condition : 'Unknown'
                },
                medications: [], // Extract from history if available
                history: result.history.map(h => ({
                    date: h.date,
                    bp: h.bp || 'N/A',
                    sugar: h.sugar || 'N/A',
                    risk: h.condition || 'Checkup'
                }))
            };
            
            // Save to localStorage
            localStorage.setItem('scannedPatientData', JSON.stringify(patientData));
            
            // Redirect
            document.getElementById('scanStatus').textContent = "✅ Data loaded! Redirecting...";
            setTimeout(() => {
                window.location.href = 'scanned-patient-history.html';
            }, 1000);
        } else {
            document.getElementById('scanStatus').textContent = "❌ " + (result.message || 'Failed to fetch patient data');
        }

    } catch (e) {
        console.error(e);
        document.getElementById('scanStatus').textContent = "❌ Error: " + e.message;
    }
}
```

## Update Patient QR Generation

In `patient-dashboard.html`, update the QR generation to include patient ID:

```javascript
async function generatePatientQR() {
    const userName = localStorage.getItem('userName');
    const userId = localStorage.getItem('userId'); // Get patient ID
    
    // NEW FORMAT: Include patient ID for backend lookup
    const qrData = {
        type: 'MEDICONNECT_PATIENT',
        patientId: userId,
        name: userName
    };
    
    // Clear previous QR
    document.getElementById('qrcode').innerHTML = "";
    
    // Generate new QR
    new QRCode(document.getElementById("qrcode"), {
        text: JSON.stringify(qrData),
        width: 200,
        height: 200,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.L
    });
    
    // Show Modal
    new bootstrap.Modal(document.getElementById('qrModal')).show();
}
```

## Benefits of This Approach

1. ✅ **Hybrid System**: Works with both offline QR data and backend
2. ✅ **Real-time Data**: Fetches latest medical history from server
3. ✅ **Fallback**: If backend fails, can still use QR data
4. ✅ **Secure**: Only stores patient ID in QR, not full medical data
5. ✅ **Scalable**: Can fetch unlimited history from backend

## Testing Steps

1. **Patient Side:**
   - Login as patient
   - Go to dashboard
   - Click "Show QR Code"
   - QR should contain: `{"type":"MEDICONNECT_PATIENT","patientId":123,"name":"John Doe"}`

2. **Doctor Side:**
   - Login as doctor
   - Go to "Scan QR"
   - Click "Start Camera" or "Upload Image"
   - Scan patient's QR code
   - Should fetch data from backend and display

3. **Verify:**
   - Check browser console for API calls
   - Verify data matches backend database
   - Test with multiple patients
